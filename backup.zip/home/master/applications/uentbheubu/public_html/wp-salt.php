<?php
/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 */
define('AUTH_KEY',         'y2AzrV8EIsRRLhItwRJen3QsXwdyw62jzBzEPRoWSAtUCm18AhftbNNEmQ1UtLhh');
define('SECURE_AUTH_KEY',  'YTj7dzUBRWmt4RVjo7Vijd9TMbbDM1LFwQ2vaWmmSpodLMUAmVIFzjgS622L6eWJ');
define('LOGGED_IN_KEY',    'yHmtmCJA2sQ3EjQRE99fC17gWsbrVw20Exh7IKPbWpgeMN3ecT9yoDim3nM6c2A4');
define('NONCE_KEY',        'ywt4wxqqRXb2oJa8pctJqYi423IwB2Ny18RJ7w4Cno3xjUfsdMcgMPLCI3vxHY8K');
define('AUTH_SALT',        'ieYdJXXgavXEeDsiImzzET3wwKF340hT6jCWqq4mvgs4RiiYEaqHRX1bCHpxryM9');
define('SECURE_AUTH_SALT', '7KN1GJwNa6dX9jSf70nDjCXTIy8IUapFnF3AUd1Kx2St4MsDSV6gcdDf8aKYLQcn');
define('LOGGED_IN_SALT',   'U18MT8Ty39Afeajtd877BpK9WtsoWiNV9wQP6o9hgDvDF4DNLJrLnL2qrjvLrpIH');
define('NONCE_SALT',       '8d2q4eQMc71igStLFtp95KgwgG3QF5nA4EzJ4cdmt5zCo8iFBAUvsW0VAig9JH0Y');
