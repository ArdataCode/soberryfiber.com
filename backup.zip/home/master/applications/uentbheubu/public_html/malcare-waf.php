<?php
// Please validate auto_prepend_file setting before removing this file

if (file_exists('/home/1095496.cloudwaysapps.com/uentbheubu/public_html/wp-content/plugins/malcare-security/protect/prepend/ignitor.php')) {
	define("MCDATAPATH", '/home/1095496.cloudwaysapps.com/uentbheubu/public_html/wp-content/mc_data/');
	define("MCCONFKEY", 'd39be77c3b28415e8105e7919334017d');
	include_once('/home/1095496.cloudwaysapps.com/uentbheubu/public_html/wp-content/plugins/malcare-security/protect/prepend/ignitor.php');
}
